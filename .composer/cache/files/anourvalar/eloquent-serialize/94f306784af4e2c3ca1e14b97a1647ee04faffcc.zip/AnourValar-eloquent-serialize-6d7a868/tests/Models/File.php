<?php

namespace AnourValar\EloquentSerialize\Tests\Models;

class File extends \Illuminate\Database\Eloquent\Model
{
}
