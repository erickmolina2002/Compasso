<?php

return [

    'actions' => [

        'logout' => [
            'label' => 'Гарах',
        ],

    ],

    'welcome' => 'Сайн байна уу?',

];
