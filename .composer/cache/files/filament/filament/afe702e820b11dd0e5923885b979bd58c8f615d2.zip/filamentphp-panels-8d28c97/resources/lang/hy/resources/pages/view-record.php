<?php

return [

    'title' => 'Դիտել :label',

    'breadcrumb' => 'Դիտել',

];
