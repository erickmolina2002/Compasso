<?php

return [

    'title' => 'Засах :label',

    'breadcrumb' => 'Засах',

    'form' => [

        'actions' => [

            'cancel' => [
                'label' => 'Цуцлах',
            ],

            'save' => [
                'label' => 'Өөрчлөлтийг хадгалах',
            ],

        ],

    ],

    'content' => [

        'tab' => [
            'label' => 'Засах',
        ],

    ],

    'notifications' => [

        'saved' => [
            'title' => 'Хадгалагдсан',
        ],

    ],

];
