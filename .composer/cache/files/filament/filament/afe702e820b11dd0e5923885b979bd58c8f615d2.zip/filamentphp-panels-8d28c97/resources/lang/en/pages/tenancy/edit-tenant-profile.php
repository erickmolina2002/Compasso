<?php

return [

    'form' => [

        'actions' => [

            'save' => [
                'label' => 'Save changes',
            ],

        ],

    ],

    'notifications' => [

        'saved' => [
            'title' => 'Saved',
        ],

    ],

];
