<?php

return [

    'title' => ':label göstər',

    'breadcrumb' => 'Göstər',

    'content' => [

        'tab' => [
            'label' => 'Göstər',
        ],

    ],

];
