<?php

return [

    'title' => 'İdarəetmə Paneli',

];
