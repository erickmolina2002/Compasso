<?php

return [

    'title' => 'Pogled :label',

    'breadcrumb' => 'Pogled',

    'content' => [

        'tab' => [
            'label' => 'Pogled',
        ],

    ],

];
