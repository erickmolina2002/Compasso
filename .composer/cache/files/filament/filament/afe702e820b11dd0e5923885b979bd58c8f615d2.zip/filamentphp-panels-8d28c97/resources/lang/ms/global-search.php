<?php

return [

    'field' => [
        'label' => 'Carian global',
        'placeholder' => 'Carian',
    ],

    'no_results_message' => 'Tiada hasil carian ditemui.',

];
