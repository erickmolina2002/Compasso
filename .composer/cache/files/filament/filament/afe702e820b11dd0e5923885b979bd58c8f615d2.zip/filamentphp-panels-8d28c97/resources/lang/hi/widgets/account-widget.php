<?php

return [

    'actions' => [

        'logout' => [
            'label' => 'साइन आउट',
        ],

    ],

    'welcome' => 'स्वागत',

];
