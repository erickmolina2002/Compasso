<?php

return [

    'field' => [
        'label' => 'Бүгдээс хайх',
        'placeholder' => 'Хайлт',
    ],

    'no_results_message' => 'Хайлтын үр дүн олдсонгүй.',

];
