<?php

return [

    'title' => 'Преглед на :label',

    'breadcrumb' => 'Преглед',

    'content' => [

        'tab' => [
            'label' => 'Детайли',
        ],

    ],

];
