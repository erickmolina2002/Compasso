<?php

return [

    'form' => [

        'actions' => [

            'save' => [
                'label' => 'שמור שינויים',
            ],

        ],

    ],

    'notifications' => [

        'saved' => [
            'title' => 'נשמר',
        ],

    ],

];
