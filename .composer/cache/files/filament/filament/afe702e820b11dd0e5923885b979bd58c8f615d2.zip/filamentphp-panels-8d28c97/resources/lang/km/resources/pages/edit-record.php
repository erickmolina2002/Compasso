<?php

return [

    'title' => 'កែប្រែ :label',

    'breadcrumb' => 'កែប្រែ',

    'form' => [

        'actions' => [

            'cancel' => [
                'label' => 'បោះបង់',
            ],

            'save' => [
                'label' => 'រក្សាទុក',
            ],

        ],

    ],

    'content' => [

        'tab' => [
            'label' => 'កែប្រែ',
        ],

    ],

    'notifications' => [

        'saved' => [
            'title' => 'បានរក្សាទុក',
        ],

    ],

];
