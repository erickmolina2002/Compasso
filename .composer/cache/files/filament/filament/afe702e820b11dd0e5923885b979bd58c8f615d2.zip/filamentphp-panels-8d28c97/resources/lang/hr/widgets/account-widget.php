<?php

return [

    'actions' => [

        'logout' => [
            'label' => 'Odjava',
        ],

    ],

    'welcome' => 'Dobrodošli',

];
