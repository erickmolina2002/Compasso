<?php

return [

    'form' => [

        'actions' => [

            'save' => [
                'label' => 'Tallenna muutokset',
            ],

        ],

    ],

    'notifications' => [

        'saved' => [
            'title' => 'Tallennettu',
        ],

    ],

];
