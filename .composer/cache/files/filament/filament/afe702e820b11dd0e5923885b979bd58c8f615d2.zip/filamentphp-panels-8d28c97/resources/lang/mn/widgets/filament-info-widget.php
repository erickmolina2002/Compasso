<?php

return [

    'actions' => [

        'open_documentation' => [
            'label' => 'Гарын авлага',
        ],

        'open_github' => [
            'label' => 'GitHub',
        ],

    ],

];
