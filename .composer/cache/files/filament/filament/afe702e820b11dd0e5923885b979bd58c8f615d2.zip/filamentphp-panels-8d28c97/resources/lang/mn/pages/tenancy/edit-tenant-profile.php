<?php

return [

    'form' => [

        'actions' => [

            'save' => [
                'label' => 'Өөрчлөлтийг хадгалах',
            ],

        ],

    ],

    'notifications' => [

        'saved' => [
            'title' => 'Хадгалагдсан',
        ],

    ],

];
