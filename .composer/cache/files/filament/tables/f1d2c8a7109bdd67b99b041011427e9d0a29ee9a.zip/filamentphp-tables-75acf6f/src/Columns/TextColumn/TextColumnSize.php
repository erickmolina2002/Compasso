<?php

namespace Filament\Tables\Columns\TextColumn;

enum TextColumnSize
{
    case ExtraSmall;

    case Small;

    case Medium;

    case Large;
}
