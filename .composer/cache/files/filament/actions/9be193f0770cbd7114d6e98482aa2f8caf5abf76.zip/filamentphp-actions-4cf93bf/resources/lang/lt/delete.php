<?php

return [

    'single' => [

        'label' => 'Ištrinti',

        'modal' => [

            'heading' => 'Ištrinti :label',

            'actions' => [

                'delete' => [
                    'label' => 'Ištrinti',
                ],

            ],

        ],

        'notifications' => [

            'deleted' => [
                'title' => 'Ištrinta',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'Ištrinti pasirinktus',

        'modal' => [

            'heading' => 'Ištrinti pasirinktus :label',

            'actions' => [

                'delete' => [
                    'label' => 'Ištrinti',
                ],

            ],

        ],

        'notifications' => [

            'deleted' => [
                'title' => 'Ištrinta',
            ],

        ],

    ],

];
