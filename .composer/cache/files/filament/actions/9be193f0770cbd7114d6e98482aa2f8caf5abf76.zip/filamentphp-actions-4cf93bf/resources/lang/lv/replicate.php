<?php

return [

    'single' => [

        'label' => 'Atkārtot',

        'modal' => [

            'heading' => 'Atkārtot :label',

            'actions' => [

                'replicate' => [
                    'label' => 'Atkārtot',
                ],

            ],

        ],

        'notifications' => [

            'replicated' => [
                'title' => 'Atkārtots',
            ],

        ],

    ],

];
