<?php

return [

    'single' => [

        'label' => '추가',

        'modal' => [

            'heading' => ':label 추가',

            'fields' => [

                'record_id' => [
                    'label' => '기록',
                ],

            ],

            'actions' => [

                'attach' => [
                    'label' => '추가',
                ],

                'attach_another' => [
                    'label' => '계속 추가',
                ],

            ],

        ],

        'notifications' => [

            'attached' => [
                'title' => '추가 완료',
            ],

        ],

    ],

];
