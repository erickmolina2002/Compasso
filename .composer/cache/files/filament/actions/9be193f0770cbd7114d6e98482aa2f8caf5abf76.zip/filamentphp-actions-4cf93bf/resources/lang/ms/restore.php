<?php

return [

    'single' => [

        'label' => 'Pulihkan',

        'modal' => [

            'heading' => 'Pulihkan :label',

            'actions' => [

                'restore' => [
                    'label' => 'Pulihkan',
                ],

            ],

        ],

        'notifications' => [

            'restored' => [
                'title' => 'Dipulihkan',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'Pulihkan pilihan',

        'modal' => [

            'heading' => 'Pulihkan pilihan :label',

            'actions' => [

                'restore' => [
                    'label' => 'Pulihkan',
                ],

            ],

        ],

        'notifications' => [

            'restored' => [
                'title' => 'Dipulihkan',
            ],

        ],

    ],

];
