<?php

return [

    'single' => [

        'label' => '연결',

        'modal' => [

            'heading' => ':label 연결',

            'fields' => [

                'record_id' => [
                    'label' => '기록',
                ],

            ],

            'actions' => [

                'associate' => [
                    'label' => '연결',
                ],

                'associate_another' => [
                    'label' => '계속 연결',
                ],

            ],

        ],

        'notifications' => [

            'associated' => [
                'title' => '연결 완료',
            ],

        ],

    ],

];
