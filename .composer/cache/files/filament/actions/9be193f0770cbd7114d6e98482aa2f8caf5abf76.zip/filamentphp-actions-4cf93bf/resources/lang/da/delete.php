<?php

return [

    'single' => [

        'label' => 'Slet',

        'modal' => [

            'heading' => 'Slet :label',

            'actions' => [

                'delete' => [
                    'label' => 'Slet',
                ],

            ],

        ],

        'notifications' => [

            'deleted' => [
                'title' => 'Slettet',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'Slet valgte',

        'modal' => [

            'heading' => 'Slet valgte :label',

            'actions' => [

                'delete' => [
                    'label' => 'Slet',
                ],

            ],

        ],

        'notifications' => [

            'deleted' => [
                'title' => 'Slettet',
            ],

        ],

    ],

];
