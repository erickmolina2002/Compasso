<?php

return [

    'single' => [

        'label' => 'Салгах',

        'modal' => [

            'heading' => 'Салгах :label',

            'actions' => [

                'detach' => [
                    'label' => 'Салгах',
                ],

            ],

        ],

        'notifications' => [

            'detached' => [
                'title' => 'Салгасан',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'Сонгосонг салгах',

        'modal' => [

            'heading' => 'Салгах :label',

            'actions' => [

                'detach' => [
                    'label' => 'Салгах',
                ],

            ],

        ],

        'notifications' => [

            'detached' => [
                'title' => 'Салгасан',
            ],

        ],

    ],

];
