<?php

return [

    'confirmation' => 'Jeste li sigurni da želite to učiniti?',

    'actions' => [

        'cancel' => [
            'label' => 'Odustani',
        ],

        'confirm' => [
            'label' => 'Potvrdi',
        ],

        'submit' => [
            'label' => 'Pošalji',
        ],

    ],

];
