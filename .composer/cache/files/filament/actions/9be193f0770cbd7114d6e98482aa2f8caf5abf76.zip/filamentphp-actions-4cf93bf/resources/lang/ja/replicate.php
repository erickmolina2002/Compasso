<?php

return [

    'single' => [

        'label' => '複製',

        'modal' => [

            'heading' => ':label 複製',

            'actions' => [

                'replicate' => [
                    'label' => '複製',
                ],

            ],

        ],

        'notifications' => [

            'replicated' => [
                'title' => '複製しました',
            ],

        ],

    ],

];
