<?php

return [

    'trigger' => [
        'label' => 'Akcije',
    ],

];
