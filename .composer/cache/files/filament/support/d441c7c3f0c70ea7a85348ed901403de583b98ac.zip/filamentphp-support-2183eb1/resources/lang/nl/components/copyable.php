<?php

return [

    'messages' => [
        'copied' => 'Gekopieerd',
    ],

];
