<?php

return [

    'actions' => [

        'close' => [
            'label' => 'Άκυρο',
        ],

    ],

];
