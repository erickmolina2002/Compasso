<?php

return [

    'actions' => [

        'close' => [
            'label' => 'بستن',
        ],

    ],

];
