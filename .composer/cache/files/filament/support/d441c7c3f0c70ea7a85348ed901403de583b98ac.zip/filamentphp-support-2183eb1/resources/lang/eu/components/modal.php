<?php

return [

    'actions' => [

        'close' => [
            'label' => 'Itxi',
        ],

    ],

];
