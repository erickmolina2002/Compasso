<?php

namespace Filament\Widgets\StatsOverviewWidget;

/**
 * @deprecated Use `Stat` instead.
 */
class Card extends Stat {}
