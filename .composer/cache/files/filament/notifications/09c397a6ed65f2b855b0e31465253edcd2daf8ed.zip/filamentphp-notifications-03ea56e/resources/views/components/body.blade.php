<div
    {{ $attributes->class(['fi-no-notification-body overflow-hidden break-words text-sm text-gray-500 dark:text-gray-400']) }}
>
    {{ $slot }}
</div>
