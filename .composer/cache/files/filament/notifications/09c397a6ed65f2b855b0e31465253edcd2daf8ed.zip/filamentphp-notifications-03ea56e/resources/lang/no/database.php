<?php

return [

    'modal' => [

        'heading' => 'Varsler',

        'actions' => [

            'clear' => [
                'label' => 'Tøm',
            ],

            'mark_all_as_read' => [
                'label' => 'Merk alle som lest',
            ],

        ],

        'empty' => [
            'heading' => 'Ingen varsler',
            'description' => 'Vennligst sjekk senere.',
        ],

    ],

];
