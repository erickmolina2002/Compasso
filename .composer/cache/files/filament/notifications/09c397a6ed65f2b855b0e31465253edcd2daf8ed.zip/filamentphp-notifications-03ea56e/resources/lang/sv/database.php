<?php

return [

    'modal' => [

        'heading' => 'Notiser',

        'actions' => [

            'clear' => [
                'label' => 'Rensa',
            ],

            'mark_all_as_read' => [
                'label' => 'Markera alla som lästa',
            ],

        ],

        'empty' => [
            'heading' => 'Inga notiser',
            'description' => 'Kolla igen lite senare.',
        ],

    ],

];
