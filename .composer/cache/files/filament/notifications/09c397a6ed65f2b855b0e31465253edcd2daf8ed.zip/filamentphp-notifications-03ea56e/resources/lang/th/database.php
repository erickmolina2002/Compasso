<?php

return [

    'modal' => [

        'heading' => 'การแจ้งเตือน',

        'actions' => [

            'clear' => [
                'label' => 'ล้าง',
            ],

            'mark_all_as_read' => [
                'label' => 'ทำเครื่องหมายทั้งหมดว่าอ่านแล้ว',
            ],

        ],

        'empty' => [
            'heading' => 'ไม่มีการแจ้งเตือน',
            'description' => 'กรุณาตรวจสอบอีกครั้งในภายหลัง',
        ],

    ],

];
