<?php

return [

    'text_entry' => [
        'more_list_items' => 'və :count daha',
    ],

];
