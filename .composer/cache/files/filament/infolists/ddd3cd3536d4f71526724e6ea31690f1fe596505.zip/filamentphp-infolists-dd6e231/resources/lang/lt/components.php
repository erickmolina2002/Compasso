<?php

return [

    'entries' => [

        'text' => [

            'actions' => [
                'collapse_list' => 'Rodyti dar :count',
                'expand_list' => 'Slėpti :count',
            ],

            'more_list_items' => 'ir dar :count',

        ],

        'key_value' => [

            'columns' => [

                'key' => [
                    'label' => 'Raktas',
                ],

                'value' => [
                    'label' => 'Reikšmė',
                ],

            ],

            'placeholder' => 'Nėra įrašų',

        ],

    ],

];
