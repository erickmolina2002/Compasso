<?php

return [

    'entries' => [

        'text' => [

            'actions' => [
                'collapse_list' => 'Hiển thị :count ít hơn',
                'expand_list' => 'Hiển thị :count thêm',
            ],

            'more_list_items' => 'và :count thêm',

        ],

        'key_value' => [

            'columns' => [

                'key' => [
                    'label' => 'Khóa',
                ],

                'value' => [
                    'label' => 'Giá trị',
                ],

            ],

            'placeholder' => 'Không có mục',

        ],

    ],

];
