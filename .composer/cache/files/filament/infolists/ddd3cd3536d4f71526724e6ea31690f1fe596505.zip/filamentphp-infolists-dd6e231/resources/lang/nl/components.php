<?php

return [

    'entries' => [

        'text' => [

            'actions' => [
                'collapse_list' => ':count minder tonen',
                'expand_list' => ':count meer tonen',
            ],

            'more_list_items' => 'en :count meer',

        ],

        'key_value' => [

            'columns' => [

                'key' => [
                    'label' => 'Sleutel',
                ],

                'value' => [
                    'label' => 'Waarde',
                ],

            ],

            'placeholder' => 'Geen items',

        ],

    ],

];
