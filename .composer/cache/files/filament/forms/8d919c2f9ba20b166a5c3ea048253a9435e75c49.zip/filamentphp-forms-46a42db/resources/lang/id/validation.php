<?php

return [

    'distinct' => [
        'must_be_selected' => 'Pilih setidaknya 1 field :attribute.',
        'only_one_must_be_selected' => 'Hanya satu field :attribute yang perlu dipilih.',
    ],

];
