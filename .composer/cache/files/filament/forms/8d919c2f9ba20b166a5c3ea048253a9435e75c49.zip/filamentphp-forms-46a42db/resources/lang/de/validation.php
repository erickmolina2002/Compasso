<?php

return [

    'distinct' => [
        'must_be_selected' => 'Wenigstens muss das :attribute ausgewählt sein.',
        'only_one_must_be_selected' => 'Nur das :attribute Feld darf ausgewählt sein.',
    ],

];
